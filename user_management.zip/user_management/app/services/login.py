from flask import Response
from app.db import models
from app.utils.db_connection import create_session


def user_login(username, password):
    if not username or not password:
        return Response("Please provide username and password")

    auth_tab = models.Auth
    sess = create_session()
    res = sess.query(auth_tab).filter(username=username).all()
    if not res:
        return Response("Incorrect Username provided")