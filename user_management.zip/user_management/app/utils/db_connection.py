from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine
from config import sqlalchemy_conn_string
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()


def create_engine_sqlite3(conn_string):
    engine = create_engine(conn_string, echo=True)
    Base.metadata.create_all(engine)
    return engine


def create_session():
    engine = create_engine_sqlite3(sqlalchemy_conn_string)
    DBSession = sessionmaker(bind=engine)
    session = DBSession()
    return session