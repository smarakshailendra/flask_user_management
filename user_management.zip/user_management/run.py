from flask import Flask,request
app = Flask(__name__)


@app.route('/login')
def login():
    return "Hello World!"

@app.route('/logout')
def logout():
    return "Hello World1!"

if __name__ == '__main__':
    app.run()