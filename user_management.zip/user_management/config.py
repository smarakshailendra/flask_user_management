import os


sqlalchemy_conn_string = "sqlite:///" + os.path.abspath(os.path.join(os.path.dirname(__file__), "db", "app.db"))